#define MAX_MESSAGE_SIZE 30
#define END_MESSAGE "The End"