gcc common.c writer.c -o writer.exe -lrt -lpthread
./writer.exe