gcc common.c reader.c -o reader.exe -lrt -lpthread
./reader.exe